package br.com.telico.student_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
